package api;

public enum ActionSelection {
	
	GREEDY, PROBALISTIC;
	
}
